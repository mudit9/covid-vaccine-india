 flask based app to find covid vaccine in india slots through pincode and date.
 http://covidvaccine.ap-south-1.elasticbeanstalk.com/
